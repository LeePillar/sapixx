<?php
/**
 * @copyright 2022 https://www.sapixx.com All rights reserved.
 * @license https://www.gnu.org/licenses/gpl-3.0.txt
 * @link https://www.sapixx.com
 * @author pillar<ltmn@qq.com>
 * 租户础控制器
 */
namespace base;

use base\model\SystemUser;
use think\facade\View;

class TenantController extends BaseController
{

    protected $middleware = ['tenant'];

   /**
     * 面包屑导航
     * 在控制器方法使用 $this->bread([['name'=>'名称',url=>'连接']]);
     */
    protected function bread(array $bread = []){ 
        if($this->app->tenant->getApps()){
            array_unshift($bread,['name'=> $this->app->tenant->getApps('title'),'icon' =>'house','url'=>(string)url('tenant/apps/index')]);
        }
        View::assign(['breadcrumb' => $bread]);
    }

   /**
     * 租户端搜索用户公共方法
     */
    public function selectUser(){ 
        if(IS_AJAX){
            $keyword = $this->request->param('keyword/s');
            $page    = $this->request->param('page/d',1);
            $list = SystemUser::apps()->withSearch(['keyword'],['keyword' => $keyword])->where(['is_delete' => 0,'is_lock'=> 0])->field(['id','apps_id','invite_code','face','nickname','phone'])->append(['as_phone'])->page($page,10)->select();
            return enjson(200,$list->toArray());
        }
    }

    /**
     * 文件统一上传服务
     */
    public function upload(){
        if(IS_POST){
            $private = $this->request->param('private/d',0);
            $local   = $this->request->param('local/d',0);
            return json($local?$this->app->upload->local():$this->app->upload->start($private));
        }else{
            $this->error('Not Found',404);
        }
    }
}