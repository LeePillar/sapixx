<?php
/**
 * @copyright 2022 https://www.sapixx.com All rights reserved.
 * @license https://www.gnu.org/licenses/gpl-3.0.txt
 * @link https://www.sapixx.com
 * @author pillar<ltmn@qq.com>
 * API访问全局入口控制
 */
declare(strict_types=1);
namespace base\constant;
use think\App;
use think\facade\Config;
use filter\Filter;
use Hashids\Hashids;
use base\model\SystemAppsClient;

/**
 * API解析到指定的应用
 */
class InitRoute
{

    /** @var App */
    protected $app;

    /**
     * 应用名称
     * @var string
     */
    protected $name;

    /**
     * 应用三方库
     * @var string
     */
    protected $composer;
    
    /**
     * 应用路径
     * @var string
     */
    protected $path;

    /**
     * 是否API
     * @var string
     */
    protected $is_api;

    /**
     * API版本
     * @var string
     */
    protected $version;

    public function __construct(App $app)
    {
        $this->app     = $app;
        $this->path    = $this->app->request->pathinfo();
        $pathinfo      = explode('/',$this->path);
        $this->is_api  = trim(strtolower(current($pathinfo)));
        $this->version = trim(strtolower(next($pathinfo) ?: ''));
        $this->name    = trim(strtolower(next($pathinfo) ?: ''));
    }

    /**
     * 多应用解析
     * @access public
     */
    public function handle()
    {
        $this->checkInstall();
        $this->setDomain();
        if ($this->is_api == 'api') {
            $this->parseApi();
        } else {
            $this->parseSapixx();
            $this->parseWeb();
        } 
        $this->LoadAppComposer();
    }

    /**
     * 解析多应用API
     * @return bool
     */
    protected function parseApi(): bool
    {
        //是否为应用API配置独立的访问域名
        $api_sub_domain = Config::get('api.api_sub_domain');
        if (!empty($api_sub_domain) && $api_sub_domain != $this->app->request->domain()) {
            abort(403,'当前访问非API有效域名');
        }
        //检测API规则
        if (empty($this->version) || !preg_match('/((^([a-zA-Z]*)$)|(^[v]\d{1}?(\.(0|[1-9]\d?)){1,2})$)/',$this->version)) {
            exitjson(403, 'API版本规则不正确,仅支持(v1.x)');
        }
        //检查API路径
        if (empty($this->name) || !is_dir($this->app->getBasePath() . $this->name . DS)) {
            exitjson(404,'没有找到应用');
        }
        Config::set(['controller_layer' => 'api\\'.str_replace('.', '_', $this->version)], 'route');
        $this->app->http->name($this->name);
        $this->app->request->setPathinfo(ltrim(substr($this->path, strlen($this->is_api . '/' . $this->version . '/' . $this->name)), '/'));
        $this->composer = $this->name.DS;
        return true;
    }

    /**
     * 解析系统API
     * @return bool
     */
    protected function parseSapixx(): bool
    {
        //解析多域名
        $bind = $this->app->config->get('app.domain_bind',[]);
        if (!empty($bind)) {
            $subDomain = $this->app->request->subDomain();
            $domain    = $this->app->request->host(true);
            if (isset($bind[$domain])) {
                $appname = $bind[$domain];
            } elseif (isset($bind[$subDomain])) {
                $appname = $bind[$subDomain];
            }else{
                abort(404,'未找到域名解析应用');
            }
            $appname = $this->is_api=='apis'?'apis':$appname;
        }else{
            $appname = $this->is_api ?: Config::get('app.default_app');
        }
        //判断是否系统应用
        if(isset(array_flip(SYSAPP)[$appname])){
            $is_apis = $this->setAppsPath($appname);
            if ($appname == 'apis' && $is_apis) {
                if (empty($this->version) || !preg_match('/((^([a-zA-Z]*)$)|(^[v]\d{1}?(\.(0|[1-9]\d?)){1,2})$)/',$this->version)) {
                    exitjson(403, 'API版本规则错误');
                }
                Config::set(['controller_layer' => 'controller\\'.str_replace('.', '_', $this->version)], 'route');
                $this->app->http->name($appname);
                $this->app->request->setPathinfo(ltrim(substr($this->path, strlen($appname . '/' . $this->version)), '/'));
            }
        }else{
            $this->composer = $appname.DS;
        }
        return true;
    }

    /**
     * 解析WEB路径
     */
    protected function parseWeb()
    {
        if($this->is_api == 'web' && !$this->app->request->is_domain){
            if (empty($this->version) || !preg_match('/^([a-zA-Z0-9]){6}$/',$this->version)) {
                abort(404,'WEB路径访问错误');
            }
            $hashids = new Hashids(config('api.jwt_salt'),6,config('api.safeid_meta'));
            $client_id = $hashids->decode($this->version);
            if(empty($client_id[0])){
                abort(404,'应用ID解码失败');
            }
            $client = SystemAppsClient::where(['id' => $client_id[0]])->cache(true)->find();
            if(empty($client)){
                abort(404,'你访问的URL不存在');
            }
            $path = PATH_APP.$client->app->appname.DS;
            if (!is_dir($path)) {
                abort(404,'未找到访问的应用');
            }
            $this->app->request->client = $client;
            $this->app->http->name($client->app->appname);
            Config::set(['controller_layer' => 'web\\'.$client->title],'route');
            Config::set(['view_path' => PATH_APP.$client->app->appname.DS.'web' . DS.'view'.DS.$client->title.DS], 'view'); 
            $this->app->request->setPathinfo(ltrim(substr($this->path,strlen($this->is_api.'/'.$this->version)),'/'));
            $this->composer = $client->app->appname.DS;
        }
    }

    /**
     * 多域名解析
     */
    private function setDomain()
    {
        $this->app->request->is_domain = false;
        if($this->is_api != 'install'){
            $subDomain = Filter::filter_str($this->app->request->host(true));
            $client = SystemAppsClient::where(['domain' => $subDomain])->cache(true)->find();
            if(empty($client)){
                return;
            }
            if($this->is_api == 'web'){
                redirect('//'.$client->domain)->send() or die;
            }
            $this->app->request->client    = $client;
            $this->app->request->is_domain = true;
            Config::set(['domain_bind' => [$client->domain => $client->app->appname]], 'app');
            Config::set(['controller_layer' => 'web\\'.$client->title],'route');
            Config::set(['view_path' => PATH_APP.$client->app->appname.DS.'web'. DS.'view'.DS.$client->title.DS], 'view'); 
        }
    }

    /**
     * 设置应用路径
     * @return bool
     */
    protected function setAppsPath($appname): bool
    {
        $path = PATH_SAPIXX.$appname.DS;
        if (!is_dir($path)) {
            return false;
        }
        $this->app->http->path($path); 
        $this->app->setAppPath($path);
        Config::set(['app_namespace' => 'platform\\'.$appname], 'app'); 
        Config::set(['view_path' => $path . 'view' . DS], 'view'); 
        return true;
    }

    /**
     * 检查是否已经正常安装系统
     */
    private function checkInstall()
    {
        if (!file_exists(PATH_RUNTIME."install.lock")) {
            Config::set(['default_app' => 'install'],'app');
            $this->is_api = 'install';
        }
    }

    /**
     * 载入应用独立资源包
     */
    private function LoadAppComposer()
    {
        $autoLoadFile = $this->app->getAppPath().$this->composer.'vendor'.DS.'autoload.php';
        if(file_exists($autoLoadFile)){
            require_once $autoLoadFile;
        }
    }
}