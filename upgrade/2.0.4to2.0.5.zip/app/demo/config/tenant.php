<?php
/**
 * 管理端管理菜单
 */
return [
    [
        'name' => '租户实例',
        'icon' => 'code-square',
        'menu' => [
            ['name' => '租户首页', 'url' => (string)url('demo/tenant/index')],
        ]
    ]
];
