<?php
/**
 * 管理端管理菜单
 */
return [
    [
        'name' => '管理实例',
        'icon' => 'code-square',
        'menu' => [
            ['name' => '管理首页', 'url' => (string)url('demo/admin/index')],
        ]
    ]
];
