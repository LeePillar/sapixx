<?php
/**
 * 自定义应用命令行
 */
return [
    'demo' => 'app\demo\command\Demo',
];