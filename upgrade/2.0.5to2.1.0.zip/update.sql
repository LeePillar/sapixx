SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ai_system_tenant_group
-- ----------------------------
DROP TABLE IF EXISTS `ai_system_tenant_group`;
CREATE TABLE `ai_system_tenant_group`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apps_id` int(11) NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `rank` int(11) NULL DEFAULT 0,
  `rank_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `rules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '[]',
  `menu` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `update_time` int(11) NULL DEFAULT NULL,
  `create_time` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '租户角色' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for ai_system_tenant
-- ----------------------------
ALTER TABLE `ai_system_tenant` ADD COLUMN `parent_apps_id` INT ( 11 ) NULL DEFAULT 0 COMMENT '子代父管理的APPS_ID';
ALTER TABLE `ai_system_tenant` ADD COLUMN `group_id` INT ( 11 ) NULL DEFAULT 0 COMMENT '角色组';