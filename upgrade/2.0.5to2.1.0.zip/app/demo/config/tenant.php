<?php
/**
 * 管理端管理菜单
 */
return [
    [
        'name' => '开发实例',
        'icon' => 'code-square',
        'menu' => [
            ['name' => '欢迎首页', 'url' => (string)url('demo/tenant/index')],
        ]
    ]
];
