<?php
/**
 * 等级体系
 */
return [
    ['title' => '通用管理','rank' => 0],
    ['title' => '订单售后','rank' => 1],
    ['title' => '订单退款','rank' => 2]
];