<?php
/**
 * @copyright   Copyright (c) 2017-2030  https://www.sapixx.com All rights reserved.
 * @license Licensed (https://www.gnu.org/licenses/gpl-3.0.txt).
 * @link https://www.sapixx.com
 * 租户端
 */
namespace app\demo\controller;
use base\TenantController;

class Cate extends TenantController
{

    
    /**
     * 栏目列表
     */
    public function index()
    {
       $this->error('效果展示');
    }

    /**
     * 增加
     */
    public function add()
    {
       $this->error('效果展示');
    }

    /**
     * 修改
     */
    public function edit()
    {
       $this->error('效果展示');
    }

    /**
     * 首页
     */
    public function delete()
    {
       $this->error('效果展示');
    }
}
